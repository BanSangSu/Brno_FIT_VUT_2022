# Face landmark dataset environment variables
FACE_LANDMARK_DATASET_SOURCE_URL = 'http://dlib.net/files/data/ibug_300W_large_face_landmark_dataset.tar.gz'
DOWNLOAD_FACE_LANDMARK_DATASET = False
REMOVE_DOWNLOADED_FACE_LANDMARK_DATASET_ARCHIVE = False

WINDOW_INIT_WIDTH = 700
WINDOW_INIT_HEIGHT = 350
