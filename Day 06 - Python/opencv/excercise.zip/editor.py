import cv2
import numpy as np


class ImageOptions:
    def __init__(self):
        self.grayscale = False
        self.flip_vertical = False
        self.flip_horizontal = False
        self.alpha = 1.0
        self.beta = 0.0
        self.blend = 1.0


# Load image from 'path' and return it
def load(path):
    return ### FILL


# Save 'image' to file 'output.jpg'
def save(image):
    ### FILL


# Show 'image' in window named 'Editor'
def display(image):
    ### FILL


# Flip 'image' horizontally and return it
def flip_horizontally(image):
    return image


# Flip 'image' horizontally and return it
def flip_vertically(image):
    return image


# Convert 'image' to grayscale
def convert_grayscale(image):
    return image


# Multiply 'image' by 'alpha', add 'beta', clip (use 'np.clip') the values between '0' and '255', and convert to 'np.uint8'
def multiply_and_add(image, alpha, beta):
    return image


# Calculate weighted sum of the two images using the 'blend_ratio', clip (use 'np.clip') the values between '0' and '255', and convert to 'np.uint8'
def blend(first_image, second_image, blend_ratio):
    return first_image


def process_image(first_image, second_image, options):
    image = blend(first_image, second_image, options.blend)

    if options.flip_horizontal:
        image = flip_horizontally(image)

    if options.flip_vertical:
        image = flip_vertically(image)

    if options.grayscale:
        image = convert_grayscale(image)

    image = multiply_and_add(image, options.alpha, options.beta)
    return image


def main():
    first_image = load("lena.jpg")
    second_image = load("opencv.jpg")
    display(first_image)

    close = False

    options = ImageOptions()

    ALPHA_MIN = 0
    ALPHA_MAX = 10
    ALPHA_STEP = 0.1

    BETA_MIN = -255
    BETA_MAX = 255
    BETA_STEP = 5

    BLEND_MIN = 0.0
    BLEND_MAX = 1.0
    BLEND_STEP = 0.1

    print("Manipulation:")
    print("q: quit")
    print("r: reset")
    print("s: save")
    print("h: flip horizontally")
    print("v: flip vertically")
    print("g: grayscale")
    print("i: increase alpha")
    print("k: decrease alpha")
    print("o: increase beta")
    print("l: decrease beta")
    print("m: increase blend")
    print("n: decrease blend")

    while not close:
        key = cv2.waitKey(100)
        if key > 0:
            if key == ord('q'):
                close = True

            elif key == ord('r'):
                options = ImageOptions()

            elif key == ord('s'):
                image_to_save = process_image(first_image, second_image, options)
                save(image_to_save)

            elif key == ord('h'):
                options.flip_horizontal = not options.flip_horizontal

            elif key == ord('v'):
                options.flip_vertical = not options.flip_vertical

            elif key == ord('g'):
                options.grayscale = not options.grayscale

            elif key == ord('i'):
                options.alpha += ALPHA_STEP

            elif key == ord('k'):
                options.alpha -= ALPHA_STEP

            elif key == ord('o'):
                options.beta += BETA_STEP

            elif key == ord('l'):
                options.beta -= BETA_STEP

            elif key == ord('m'):
                options.blend += BLEND_STEP

            elif key == ord('n'):
                options.blend -= BLEND_STEP

            options.alpha = np.clip(options.alpha, ALPHA_MIN, ALPHA_MAX)
            options.beta = np.clip(options.beta, BETA_MIN, BETA_MAX)
            options.blend = np.clip(options.blend, BLEND_MIN, BLEND_MAX)

            image_to_display = process_image(first_image, second_image, options)
            display(image_to_display)

    cv2.destroyAllWindows()

    return 0


if __name__ == "__main__":
    exit(main())
